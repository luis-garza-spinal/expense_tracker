import { View, Text, StyleSheet } from 'react-native'
import { spacing } from '../../../shared/theme';

interface SummaryDetailsOverviewProps {
    overview: SummaryDetailsOverviewState
}


interface SummaryDetailsOverviewState {
    range: {
        start: Date | null, end: Date | null
    };
    total: number;
    mostExpensiveCategory: {
        name: string,
        amount: number
    }
    mostExpensiveItem: {
        name: string,
        amount: number
    }
}


export function SummaryDetailsOverview({ overview }: SummaryDetailsOverviewProps) {


    return (
        <View style={styles.overviewContainer}>
            <Text>Dates {overview.range.start?.toISOString().split('T')[0]} - {overview.range.end?.toISOString().split('T')[0]}</Text>
            <Text>Total Expense: ${overview.total}</Text>
            <Text>Most Expensive Category: {overview.mostExpensiveCategory.name} - ${overview.mostExpensiveCategory.amount}</Text>
            <Text>Most Expensive Item: {overview.mostExpensiveItem.name} - ${overview.mostExpensiveItem.amount}</Text>
        </View>
    )
}

const styles = StyleSheet.create({
    overviewContainer: {
        marginTop: spacing.lg,
        alignItems: 'center'        
    },


})