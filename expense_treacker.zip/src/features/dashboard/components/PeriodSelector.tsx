import React from 'react';
import { View, StyleSheet } from 'react-native';
import { SegmentedButtons } from 'react-native-paper';
import { ReportPeriod } from '../types/report';
import { spacing } from '../../../shared/theme/spacing';
import { useDashboardFilters } from '../stores/useDashboardFilters';

const PERIOD_OPTIONS = [
  { value: 'daily', label: 'Day' },
  { value: 'weekly', label: 'Week' },
  { value: 'bi-weekly', label: '2 Weeks' },
  { value: 'monthly', label: 'Month' },
];

export function PeriodSelector() {
  const { setPeriod, filters } = useDashboardFilters();

  const onChange = (value: string) => {
    setPeriod(value as ReportPeriod)
  }

  return (
    <View style={styles.container} testID="period-selector">
      <SegmentedButtons
        value={filters.period}
        onValueChange={onChange}
        buttons={PERIOD_OPTIONS}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  }
});

