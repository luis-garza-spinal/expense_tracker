import { createStore } from "zustand";
import { ExpenseSummary } from "../types/report";



// I want expense details based on the breakdwon
// Details of each expense, title, amount, percentage based on selected period 
// (each category has a % of the total so each expense will be calculate under category %) or maybe uinder the 100%

// Expense: Title, amount, date, percentage (maybe calculated on the fly)


interface useDashboardExpensesStore {
    expenses: ExpenseSummary[];
    setExpenses: (expenses: ExpenseSummary[]) => void;
}

export const useDashboardExpenses = createStore((state) => {

});