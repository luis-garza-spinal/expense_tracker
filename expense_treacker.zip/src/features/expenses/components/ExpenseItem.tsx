import React from 'react';
import { StyleSheet, View } from 'react-native';
import { Card, Text, Chip } from 'react-native-paper';
import { Expense } from '../types/expense';
import { colors } from '../../../shared/theme/colors';
import { spacing } from '../../../shared/theme/spacing';

interface ExpenseItemProps {
  expense: Expense;
}

export function ExpenseItem({ expense }: ExpenseItemProps) {
  return (
    <Card style={styles.card} testID={`expense-item-${expense.id}`}>
      <Card.Content style={styles.content}>

        <View style={styles.titleContainer}>
          {expense.description ? (
            <Text variant="bodyMedium" style={styles.description} testID="expense-description">
              {expense.description}
            </Text>
          ) : <></>}
          <Chip style={styles.chip} textStyle={styles.chipText} testID="expense-category">
            {expense.category}
          </Chip>
        </View>

        <View style={styles.titleContainer}>
          <Text variant="titleMedium" style={styles.amount} testID="expense-amount">
            -${expense.amount.toFixed(2)}
          </Text>
          <Text variant="bodySmall" style={styles.date} testID="expense-date">
            {expense.date}
          </Text>
        </View>
      </Card.Content>
    </Card>
  );
}

const styles = StyleSheet.create({
  card: {
    marginHorizontal: spacing.md,
    marginBottom: spacing.sm,
    backgroundColor: colors.surface,
  },
  content: {
    flexDirection: 'column',
  },
  amount: {
    color: colors.error,
    fontWeight: '700',
    marginBottom: spacing.xs,
  },
  chip: {
    alignSelf: 'flex-start',
    backgroundColor: colors.secondaryLight,
    marginBottom: spacing.xs    
  },
  chipText: {
    color: colors.textSecondary,
    fontSize: 12,
    fontWeight: 500
  },
  date: {
    color: colors.textSecondary,
    marginBottom: spacing.xs,
  },
  description: {
    color: colors.text,
    fontWeight: 600
  },
  titleContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  }
});
